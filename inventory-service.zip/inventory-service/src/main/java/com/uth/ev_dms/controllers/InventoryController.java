package com.uth.ev_dms.controllers;

import com.uth.ev_dms.service.dto.InventoryAdjustmentRequest;
import com.uth.ev_dms.service.dto.InventoryDto;
import com.uth.ev_dms.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
public class InventoryController {

    private final InventoryService inventoryService;

    // Dealer xem toàn bộ kho của dealer
    @GetMapping("/dealer/{dealerId}")
    @PreAuthorize("hasAnyRole('DEALER', 'ADMIN')")
    public ResponseEntity<List<InventoryDto>> getByDealer(@PathVariable Long dealerId) {
        return ResponseEntity.ok(inventoryService.getInventoryByDealer(dealerId));
    }

    // Branch xem kho tại chi nhánh
    @GetMapping("/branch/{branchId}")
    @PreAuthorize("hasAnyRole('DEALER', 'ADMIN')")
    public ResponseEntity<List<InventoryDto>> getByBranch(@PathVariable Long branchId) {
        return ResponseEntity.ok(inventoryService.getInventoryByBranch(branchId));
    }

    // Lấy 1 dòng inventory theo branch + trim
    @GetMapping("/branch/{branchId}/trim/{trimId}")
    @PreAuthorize("hasAnyRole('DEALER', 'ADMIN')")
    public ResponseEntity<InventoryDto> getByBranchAndTrim(@PathVariable Long branchId,
                                                           @PathVariable Long trimId) {
        return ResponseEntity.ok(inventoryService.getByBranchAndTrim(branchId, trimId));
    }

    // Nhập / xuất kho (dealer dùng)
    @PostMapping("/adjust")
    @PreAuthorize("hasAnyRole('DEALER', 'ADMIN')")
    public ResponseEntity<InventoryDto> adjustInventory(@RequestBody InventoryAdjustmentRequest request) {
        return ResponseEntity.ok(inventoryService.adjustInventory(request));
    }
}
