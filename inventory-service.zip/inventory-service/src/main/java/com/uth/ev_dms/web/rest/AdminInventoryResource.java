package com.uth.ev_dms.web.rest;

import com.uth.ev_dms.domain.Inventory;
import com.uth.ev_dms.security.SecurityUtils;
import com.uth.ev_dms.service.InventoryService;
import com.uth.ev_dms.service.dto.InventoryDto;
import com.uth.ev_dms.service.dto.InventoryUpdateRequest;
import com.uth.ev_dms.service.mapper.InventoryMapper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin/inventories")
@RequiredArgsConstructor
public class AdminInventoryResource {

    private final InventoryService inventoryService;
    private final InventoryMapper inventoryMapper;

    /**
     * GET  /api/admin/inventories : lấy toàn bộ inventory (Admin/EVM).
     */
    @GetMapping
    @PreAuthorize("hasAuthority(\"ROLE_ADMIN\")")
    public ResponseEntity<List<InventoryDto>> getAllInventories() {
        List<InventoryDto> dtos = inventoryService.findAll()
                .stream()
                .map(inventoryMapper::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    /**
     * GET  /api/admin/inventories/{id} : lấy 1 inventory theo id.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority(\"ROLE_ADMIN\")")
    public ResponseEntity<InventoryDto> getInventory(@PathVariable Long id) {
        return inventoryService.findById(id)
                .map(inventoryMapper::toDto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * POST  /api/admin/inventories : tạo mới inventory.
     * Body có thể là InventoryDto (qtyOnHand, dealerId, branchId, trimId, locationType...)
     * Tùy bạn dùng form nào ở FE.
     */
    @PostMapping
    @PreAuthorize("hasAuthority(\"ROLE_ADMIN\")")
    public ResponseEntity<InventoryDto> createInventory(@RequestBody Inventory inventory) {

        // Lấy username hiện tại
        String username = SecurityUtils.getCurrentUserLogin().orElse("system");

        Inventory saved = inventoryService.createInventory(inventory, username);
        InventoryDto dto = inventoryMapper.toDto(saved);

        return ResponseEntity
                .created(URI.create("/api/admin/inventories/" + saved.getId()))
                .body(dto);
    }

    /**
     * PUT  /api/admin/inventories/{id} : điều chỉnh qtyOnHand + ghi log adjustment.
     * Body: InventoryUpdateRequest { id, qtyOnHand, note }
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority(\"ROLE_ADMIN\")")
    public ResponseEntity<InventoryDto> updateInventory(
            @PathVariable Long id,
            @Valid @RequestBody InventoryUpdateRequest request
    ) {
        // ensure id khớp
        request.setId(id);

        String username = SecurityUtils.getCurrentUserLogin().orElse("system");

        Inventory updated = inventoryService.updateInventory(request, username);
        return ResponseEntity.ok(inventoryMapper.toDto(updated));
    }

    /**
     * DELETE  /api/admin/inventories/{id} : xóa inventory.
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority(\"ROLE_ADMIN\")")
    public ResponseEntity<Void> deleteInventory(@PathVariable Long id) {
        inventoryService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
