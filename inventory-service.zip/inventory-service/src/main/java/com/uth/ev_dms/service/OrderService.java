package com.uth.ev_dms.service;

public interface OrderService {
    void confirmOrder(Long orderId);

    void shipOrder(Long orderId);

    void cancelOrder(Long orderId);
}
