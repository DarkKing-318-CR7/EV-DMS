package com.uth.ev_dms.service.mapper;

import com.uth.ev_dms.domain.Inventory;
import com.uth.ev_dms.service.dto.InventoryDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface InventoryMapper {

    @Mapping(source = "dealer.id", target = "dealerId")
    @Mapping(source = "branch.id", target = "branchId")
    @Mapping(source = "trim.id", target = "trimId")
    @Mapping(source = "trim.name", target = "trimName")
    @Mapping(source = "trim.modelName", target = "modelName")
    @Mapping(source = "qtyOnHand", target = "quantityOnHand")
    @Mapping(target = "available", expression = "java(calculateAvailable(inv))")
    InventoryDto toDto(Inventory inv);

    // Nếu bạn cần map ngược lại DTO -> entity thì thêm method này,
    // còn không dùng có thể xoá đi cho đỡ rối.
    // @Mapping(target = "dealer", ignore = true)
    // @Mapping(target = "branch", ignore = true)
    // @Mapping(target = "trim", ignore = true)
    // Inventory toEntity(InventoryDto dto);

    default Integer calculateAvailable(Inventory inv) {
        if (inv == null) return 0;
        int onHand = inv.getQtyOnHand() == null ? 0 : inv.getQtyOnHand();
        int reserved = inv.getReserved() == null ? 0 : inv.getReserved();
        return onHand - reserved;
    }
}
