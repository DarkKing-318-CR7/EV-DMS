package com.uth.ev_dms.service.impl;

import com.uth.ev_dms.client.InventoryClient;
import com.uth.ev_dms.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final InventoryClient inventoryClient;

    @Override
    public void confirmOrder(Long orderId) {
        // logic lưu đơn, validate, ...
        inventoryClient.allocate(orderId);
    }

    @Override
    public void shipOrder(Long orderId) {
        // logic cập nhật trạng thái đơn, ...
        inventoryClient.ship(orderId);
    }

    @Override
    public void cancelOrder(Long orderId) {
        // logic update status = CANCELLED, ...
        inventoryClient.release(orderId);
    }
}
