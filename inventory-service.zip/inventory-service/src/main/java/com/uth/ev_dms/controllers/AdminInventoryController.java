package com.uth.ev_dms.controllers;

import com.uth.ev_dms.service.dto.InventoryDto;
import com.uth.ev_dms.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/inventory")
@RequiredArgsConstructor
public class AdminInventoryController {

    private final InventoryService inventoryService;

    // ADMIN xem toàn bộ kho hệ thống
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<InventoryDto>> getAll() {
        return ResponseEntity.ok(inventoryService.getAllInventories());
    }

    // Nếu muốn: admin xem theo dealer
    @GetMapping("/dealer/{dealerId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<InventoryDto>> getByDealerForAdmin(@PathVariable Long dealerId) {
        return ResponseEntity.ok(inventoryService.getInventoryByDealer(dealerId));
    }

    // Nếu muốn: admin xem theo branch
    @GetMapping("/branch/{branchId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<InventoryDto>> getByBranchForAdmin(@PathVariable Long branchId) {
        return ResponseEntity.ok(inventoryService.getInventoryByBranch(branchId));
    }
}
