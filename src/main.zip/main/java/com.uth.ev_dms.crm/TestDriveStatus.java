package com.uth.ev_dms.crm;

public enum TestDriveStatus {
    PENDING, CONFIRMED, COMPLETED, CANCELED
}
