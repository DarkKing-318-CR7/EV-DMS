package com.uth.ev_dms.domain;

public enum CustomerStatus {
    ACTIVE, INACTIVE
}
