package com.uth.ev_dms.domain;

public enum PaymentType {
    CASH, INSTALLMENT
}
