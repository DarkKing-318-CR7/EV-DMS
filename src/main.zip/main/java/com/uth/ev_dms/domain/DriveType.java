package com.uth.ev_dms.domain;

public enum DriveType {
    FWD, RWD, AWD
}
