package com.uth.ev_dms.domain;

public enum BodyType { SUV, SEDAN, HATCHBACK, CROSSOVER, COUPE, PICKUP, VAN }
