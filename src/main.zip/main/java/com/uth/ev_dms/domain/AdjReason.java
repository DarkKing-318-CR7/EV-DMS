package com.uth.ev_dms.domain;

public enum AdjReason {
    ALLOCATE, RECALL, ADJUST
}
