package com.uth.ev_dms.support;

public class SupportRequest {
    private String name;
    private String email;
    private String message;
    // Getters & setters
    public String getName() { return name; }
    public void setName(String n) { this.name = n; }
    public String getEmail() { return email; }
    public void setEmail(String e) { this.email = e; }
    public String getMessage() { return message; }
    public void setMessage(String m) { this.message = m; }
}
