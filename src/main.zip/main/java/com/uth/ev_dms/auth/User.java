package com.uth.ev_dms.auth;

import com.uth.ev_dms.domain.Dealer;   // ✅ thêm
import com.uth.ev_dms.domain.Region;   // ✅ thêm
import jakarta.persistence.*;
import lombok.*;
import java.util.Set;

@Entity
@Table(name = "users")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 100)
    private String username;

    @Column(nullable = false, length = 255)
    private String password;

    @Column(name = "full_name", length = 150)
    private String fullName;

    @Column(length = 150)
    private String email;

    @Builder.Default
    private boolean enabled = true;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "users_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles;

    // ✅ thêm 2 quan hệ dưới đây
    @ManyToOne
    @JoinColumn(name = "dealer_id")     // cột khóa ngoại trong bảng users
    private Dealer dealer;

    @ManyToOne
    @JoinColumn(name = "region_id")     // cột khóa ngoại trong bảng users
    private Region region;
}
